'use client'
import Faq from '@/components/landing/Faq'
import React from 'react'

const page = () => {
  return (
    <div>
      <Faq />
    </div>
  )
}

export default page
