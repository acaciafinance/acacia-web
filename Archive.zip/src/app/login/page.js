'use client'
import Login from '@/components/access/login/Login'
import React from 'react'

const page = () => {
  return (
    <div>
      <Login />
    </div>
  )
}

export default page
