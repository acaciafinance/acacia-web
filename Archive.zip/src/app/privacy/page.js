import PrivacyPolicy from '@/components/landing/PrivacyPolicy'
import React from 'react'

const page = () => {
  return (
    <div>
      <PrivacyPolicy />
    </div>
  )
}

export default page
