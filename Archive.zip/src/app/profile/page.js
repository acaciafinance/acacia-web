'use client'
// import ProfileHome from '@/components/profile/ProfileHome'
import React from 'react'

const page = () => {
  return (
    <div>
      Holla
    </div>
  )
}

export default page
