import TermsOfService from '@/components/landing/TermsOfService'
import React from 'react'

const page = () => {
  return (
    <div>
      <TermsOfService />
    </div>
  )
}

export default page
