'use client'
import SingleTransaction from '@/components/transactions/SingleTransaction'
import React from 'react'

const page = () => {
  return (
    <div>
      <SingleTransaction />
    </div>
  )
}

export default page
