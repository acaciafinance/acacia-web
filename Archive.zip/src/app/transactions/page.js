import TransactionTable from '@/components/transactions/user-transactions/MyTransactions'
import React from 'react'

const page = () => {
  return (
    <div>
      <TransactionTable />
    </div>
  )
}

export default page
